#pragma once

class Singleton {
  private:
    Singleton();
    static Singleton* instance;

  public:
    // Delete and disallow copy constructor and copy assignment.
    Singleton(const Singleton& other) = delete;
    Singleton& operator=(const Singleton& other) = delete;
    
    static Singleton* GetInstance();
    ~Singleton();

    // Any other business logic
    void DoFun() const;

};