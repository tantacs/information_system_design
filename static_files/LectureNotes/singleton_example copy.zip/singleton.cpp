#include "singelton.h"
#include <iostream>
#include <memory>

using std::cout;
using std::endl;


Singleton::Singleton() {
}

Singleton::~Singleton() {
    cout << "Destroying object at : " << this << endl;
}

Singleton* Singleton::instance = nullptr;

Singleton* Singleton::GetInstance() {
    if (instance == nullptr) {
        // Bonus question: think about the lifetime of this object. When is it going to be destroyed.
       instance = new Singleton();
    }
    return instance; 
}

void Singleton::DoFun() const {
    cout << "Doing function using singeleton at " << this << endl;
}

