#include "singelton.h"

int main() {
    Singleton *obj = Singleton::GetInstance();
    obj->DoFun();
    // Calling GetInstance() again will return a pointer to the same object.
    Singleton* second_obj = Singleton::GetInstance();
    second_obj->DoFun();
    // You can use a reference to singleton
    Singleton& third_obj = *Singleton::GetInstance();
    third_obj.DoFun();
    // But you cannot copy it. This line will not work.
    //
    // Singleton fourth_obj = *Singleton::GetInstance();
    //
    return 0;
}