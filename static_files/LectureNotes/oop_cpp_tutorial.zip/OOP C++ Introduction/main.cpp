//Object Oriented Programming (OOP) in C++ Course
//https://www.youtube.com/watch?v=wN0x9eZLix4

//How to Create a Simple Makefile - Introduction to Makefiles
//https://www.youtube.com/watch?v=_r7i5X0rXJk
//https://stackoverflow.com/questions/32127524/how-to-install-and-use-make-in-windows

//UML Class Diagram Tutorial
//https://www.youtube.com/watch?v=UI6lqHOVHic

#include "person.h"
#include "Employee.h"
#include "Developer.h"
#include "Teacher.h"

#include <iostream>
using namespace std;

int main()
{
	Developer d1("name1","comp1",20,"python");
	Teacher t1("name2","comp2",20,"math");

	Person* p;

	while(1)
	{
		cout<<"choose an employee (Enter 0 for developer or 1 for teacher):";
		int x; cin>>x;
		if(x==0) p=&d1;
		else if(x==1) p=&t1;
		else break;
		p->introduceyourself();
	}
}
