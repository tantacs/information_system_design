#include "Employee.h"
#include "Teacher.h"
#include <iostream>
using namespace std;

	Teacher::Teacher(string n,string c,int a,string sb):Employee(n,c,a)
	{
		Subject=sb;
	}
	void Teacher::introduceyourself()
	{
		cout<<"I am a teacher"<<endl;
		Employee::introduceyourself();		
	}
	void Teacher::teach()
	{
		cout<<"Iam teaching "<<Subject<<endl;
	}
