#pragma once
class Person
{
public:
	virtual void introduceyourself()=0;
};