#pragma once
#include "employee.h"
#include <iostream>
using namespace std;

class Developer : public Employee
{
	string ProgrammingLanguage;

public:
	Developer(string n,string c,int a,string pl);

	void setProgrammingLanguage(string pl);
	string getProgrammingLanguage();

	void introduceyourself();

	void code();
};