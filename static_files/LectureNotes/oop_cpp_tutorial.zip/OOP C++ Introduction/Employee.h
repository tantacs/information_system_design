#pragma once
#include "person.h"
#include <iostream>
using namespace std;

class Employee : public Person
{
	string Name;
	string Company;
	int Age;

public:
	Employee();
	Employee(string n,string c,int a);

	void setName(string n);
	string getName();

	void setCompany(string c);
	string getCompany();

	void setAge(int a);
	int getAge();

	void introduceyourself();
};