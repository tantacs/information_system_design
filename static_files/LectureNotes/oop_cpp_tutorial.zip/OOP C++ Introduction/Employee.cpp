#include "Employee.h"
#include <iostream>
using namespace std;

	Employee::Employee() {}

	Employee::Employee(string n,string c,int a)
	{
		Name=n; Company=c; Age=a;
	}

	void Employee::setName(string n) { Name=n; }
	string Employee::getName() { return Name; }

	void Employee::setCompany(string c) { Company=c; }
	string Employee::getCompany() { return Company; }

	void Employee::setAge(int a) { Age=a; }
	int Employee::getAge() { return Age; }

	void Employee::introduceyourself()
	{
		cout<<Name<<" - "<<Company<<" - "<<Age<<endl;
	}