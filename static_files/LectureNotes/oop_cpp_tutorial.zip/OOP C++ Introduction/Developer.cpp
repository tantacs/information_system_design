#include "employee.h"
#include "Developer.h"
#include <iostream>
using namespace std;

	Developer::Developer(string n,string c,int a,string pl):Employee(n,c,a)
	{
		ProgrammingLanguage=pl;
	}

	void Developer::setProgrammingLanguage(string pl) { ProgrammingLanguage=pl; }
	string Developer::getProgrammingLanguage() { return ProgrammingLanguage; }

	void Developer::introduceyourself()
	{
		cout<<"I am a developer"<<endl;
		Employee::introduceyourself();
	}

	void Developer::code()
	{
		cout<<"Writing code in "<<ProgrammingLanguage<<endl;
	}