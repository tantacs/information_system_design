#pragma once
#include "Employee.h"
#include <iostream>
using namespace std;

class Teacher : public Employee
{
	string Subject;
public:
	Teacher(string n,string c,int a,string sb);
	void introduceyourself();
	void teach();
};